﻿
namespace NeedForSpeed.Motorcycles
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int horsepower, double fuel) 
            : base(horsepower, fuel)
        {
        }
    }
}
