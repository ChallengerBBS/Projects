﻿using PlayersAndMonsters.Elfs;
using PlayersAndMonsters.Knights;
using PlayersAndMonsters.Wizards;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}