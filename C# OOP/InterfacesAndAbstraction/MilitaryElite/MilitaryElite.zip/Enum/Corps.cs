﻿namespace MilitaryElite.Enum
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
