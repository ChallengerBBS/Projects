﻿namespace BirthDayCelebration.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
