﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthDayCelebration.Interfaces
{
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}
