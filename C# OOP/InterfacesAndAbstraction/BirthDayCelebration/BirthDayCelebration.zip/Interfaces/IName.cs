﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthDayCelebration.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
