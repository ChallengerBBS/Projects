﻿namespace Telephony.Interfaces
{
    public interface ICallable
    {
        string Call(string phoneNumber);
    }
}
