﻿using System;
using System.Linq;

namespace P03_JediGalaxy
{
    class Program
    {
        static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
