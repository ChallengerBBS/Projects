﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P02_CarsSalesman
{
    public class Program
    {
        static void Main()
        {
            Runner runner = new Runner();
            runner.Start();
        }


    }
}
