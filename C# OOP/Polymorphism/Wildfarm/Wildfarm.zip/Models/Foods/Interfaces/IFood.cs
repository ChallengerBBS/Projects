﻿
namespace Wildfarm.Models.Foods.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
