﻿
namespace Wildfarm.Models.Foods.Entities
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
